#!/bin/bash
# ============================================================
# Noisy-Neighbor Experiment Matrix Runner
# ============================================================
#
# Bu script tüm victim × attacker × run kombinasyonlarını otomatik
# çalıştırır ve telemetry CSV'leri üretir.
#
# ÖNCEKİ HATA:
#   - Sadece 2 victim (sysbench, redis-benchmark)
#   - Sadece 2 attacker + none (STREAM, stress-ng)
#   - Sadece 3 run per pair
#   - Toplam: 2 × 3 × 3 = 18 experiment (kuvvetsiz dataset)
#
# YENİ MATRIX:
#   - 5 victim workload: sysbench, redis-benchmark, mcf, x264, stream-victim
#   - 5 attacker workload: none, STREAM, stress-ng, mcf-attacker, custom-bw
#   - 10 run per pair (akademik standart)
#   - Toplam: 5 × 5 × 10 = 250 experiment
#
# Not: x264 ve mcf yüklü değilse otomatik atlanır (uyarı mesajı ile).
# ============================================================

set -u  # Bilinmeyen değişken hatası ver

# --- Path Ayarları ---
CLOUD_DIR="${HOME}/cloud"
TELEMETRY_PY="${CLOUD_DIR}/telemetry.py"
TELEMETRY_VENV="${CLOUD_DIR}/telemetry_env/bin/python"
STREAM_BIN="${CLOUD_DIR}/STREAM/stream_c.exe"

# --- Experiment Matrix ---
VICTIMS=("sysbench" "redis-benchmark" "mcf" "x264")
ATTACKERS=("none" "STREAM" "stress-ng" "mcf-attacker")
RUNS=10

VICTIM_CORE=0
ATTACKER_CORE=1
NUMA_NODE=0
DURATION=60
COOLDOWN=5

# --- İstatistik ---
TOTAL_EXPERIMENTS=$((${#VICTIMS[@]} * ${#ATTACKERS[@]} * RUNS))
COMPLETED=0
SKIPPED=0
FAILED=0

# --- Renkli output ---
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo "========================================================"
echo "  Noisy-Neighbor Experiment Matrix Runner"
echo "========================================================"
echo "  Victims:   ${VICTIMS[@]}"
echo "  Attackers: ${ATTACKERS[@]}"
echo "  Runs per pair: $RUNS"
echo "  Toplam experiment: $TOTAL_EXPERIMENTS"
echo "  Tahmini süre: $((TOTAL_EXPERIMENTS * (DURATION + COOLDOWN) / 60)) dakika"
echo "========================================================"

# --- Sudo check ---
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[-] Bu script sudo gerektirir (perf için). 'sudo bash run_experiments.sh' deneyin.${NC}"
    exit 1
fi

# --- Workload availability check ---
check_workload() {
    local name="$1"
    case "$name" in
        sysbench)
            command -v sysbench >/dev/null 2>&1
            ;;
        redis-benchmark)
            command -v redis-benchmark >/dev/null 2>&1
            ;;
        mcf|mcf-attacker)
            command -v mcf >/dev/null 2>&1 || command -v 605.mcf_s >/dev/null 2>&1
            ;;
        x264)
            command -v x264 >/dev/null 2>&1
            ;;
        STREAM)
            [ -x "$STREAM_BIN" ]
            ;;
        stress-ng)
            command -v stress-ng >/dev/null 2>&1
            ;;
        none)
            true
            ;;
        *)
            false
            ;;
    esac
}

# --- Victim launcher ---
launch_victim() {
    local victim="$1"
    case "$victim" in
        sysbench)
            while true; do
                numactl --physcpubind=$VICTIM_CORE --membind=$NUMA_NODE \
                    sysbench cpu --cpu-max-prime=50000 run > /dev/null 2>&1
            done &
            ;;
        redis-benchmark)
            while true; do
                numactl --physcpubind=$VICTIM_CORE --membind=$NUMA_NODE \
                    redis-benchmark -t set,get -n 100000000 -q > /dev/null 2>&1
            done &
            ;;
        mcf)
            while true; do
                numactl --physcpubind=$VICTIM_CORE --membind=$NUMA_NODE \
                    mcf inp.in > /dev/null 2>&1
            done &
            ;;
        x264)
            while true; do
                numactl --physcpubind=$VICTIM_CORE --membind=$NUMA_NODE \
                    x264 --crf 20 -o /dev/null /tmp/test_video.y4m > /dev/null 2>&1
            done &
            ;;
        *)
            echo -e "${RED}[-] Bilinmeyen victim: $victim${NC}"
            return 1
            ;;
    esac
    echo $!
}

# --- Attacker launcher ---
launch_attacker() {
    local attacker="$1"
    case "$attacker" in
        none)
            echo ""
            ;;
        STREAM)
            while true; do
                numactl --physcpubind=$ATTACKER_CORE --membind=$NUMA_NODE \
                    "$STREAM_BIN" > /dev/null 2>&1
            done &
            echo $!
            ;;
        stress-ng)
            numactl --physcpubind=$ATTACKER_CORE --membind=$NUMA_NODE \
                stress-ng --matrix 1 --cache 1 > /dev/null 2>&1 &
            echo $!
            ;;
        mcf-attacker)
            while true; do
                numactl --physcpubind=$ATTACKER_CORE --membind=$NUMA_NODE \
                    mcf inp.in > /dev/null 2>&1
            done &
            echo $!
            ;;
        *)
            echo -e "${RED}[-] Bilinmeyen attacker: $attacker${NC}" >&2
            return 1
            ;;
    esac
}

# --- Cleanup ---
cleanup_workloads() {
    local victim="$1"
    local attacker="$2"
    local victim_pid="$3"
    local attacker_pid="$4"

    # Wrapper while loop'ları sonlandır
    [ -n "$victim_pid" ] && kill -9 "$victim_pid" 2>/dev/null
    [ -n "$attacker_pid" ] && kill -9 "$attacker_pid" 2>/dev/null

    # Worker process'leri öldür
    pkill -9 -f "sysbench cpu" 2>/dev/null
    pkill -9 -f "redis-benchmark" 2>/dev/null
    pkill -9 -f "stream_c" 2>/dev/null
    pkill -9 -f "stress-ng" 2>/dev/null
    pkill -9 -f "mcf inp" 2>/dev/null
    pkill -9 -f "x264 --crf" 2>/dev/null

    sleep 1
}

# --- Ana döngü ---
START_TIME=$(date +%s)

for victim in "${VICTIMS[@]}"; do
    # Victim mevcut mu kontrol et
    if ! check_workload "$victim"; then
        echo -e "${YELLOW}[!] $victim yüklü değil, $(( ${#ATTACKERS[@]} * RUNS )) experiment atlanıyor.${NC}"
        SKIPPED=$(( SKIPPED + ${#ATTACKERS[@]} * RUNS ))
        continue
    fi

    for attacker in "${ATTACKERS[@]}"; do
        # Attacker mevcut mu
        if ! check_workload "$attacker"; then
            echo -e "${YELLOW}[!] $attacker yüklü değil, $RUNS experiment atlanıyor.${NC}"
            SKIPPED=$(( SKIPPED + RUNS ))
            continue
        fi

        for run in $(seq 1 $RUNS); do
            echo ""
            echo "--------------------------------------------------------"
            echo "[$(date '+%H:%M:%S')] [$((COMPLETED + 1))/$TOTAL_EXPERIMENTS] "\
                 "$victim (core $VICTIM_CORE) vs $attacker (core $ATTACKER_CORE) — run $run"
            echo "--------------------------------------------------------"

            # 1. Attacker başlat (varsa)
            ATTACKER_PID=""
            if [ "$attacker" != "none" ]; then
                ATTACKER_PID=$(launch_attacker "$attacker")
            fi

            # 2. Victim başlat
            VICTIM_PID=$(launch_victim "$victim")
            if [ -z "$VICTIM_PID" ]; then
                echo -e "${RED}[-] Victim başlatılamadı, atlanıyor.${NC}"
                FAILED=$((FAILED + 1))
                continue
            fi

            # 3. Stabilize ol
            sleep 2

            # 4. Telemetry ölç
            if [ -x "$TELEMETRY_VENV" ]; then
                PYTHON_BIN="$TELEMETRY_VENV"
            else
                PYTHON_BIN="python3"
            fi

            if "$PYTHON_BIN" "$TELEMETRY_PY" \
                --victim "$victim" \
                --attacker "$attacker" \
                --run_id "$run" \
                --duration "$DURATION"; then
                COMPLETED=$((COMPLETED + 1))
                echo -e "${GREEN}[✓] Tamamlandı.${NC}"
            else
                FAILED=$((FAILED + 1))
                echo -e "${RED}[-] Telemetry başarısız.${NC}"
            fi

            # 5. Cleanup
            cleanup_workloads "$victim" "$attacker" "$VICTIM_PID" "$ATTACKER_PID"

            # 6. Cooldown
            echo "[*] $COOLDOWN saniye cooldown..."
            sleep $COOLDOWN
        done
    done
done

# --- Özet ---
END_TIME=$(date +%s)
ELAPSED=$((END_TIME - START_TIME))

echo ""
echo "========================================================"
echo "  Experiment Matrix Tamamlandı"
echo "========================================================"
echo "  Tamamlanan:  $COMPLETED"
echo "  Atlanan:     $SKIPPED"
echo "  Başarısız:   $FAILED"
echo "  Toplam:      $TOTAL_EXPERIMENTS"
echo "  Geçen süre:  $((ELAPSED / 60)) dakika $((ELAPSED % 60)) saniye"
echo "========================================================"
echo ""
echo "Sıradaki adım:"
echo "  $PYTHON_BIN train_model.py"
echo ""
